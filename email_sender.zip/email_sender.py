import boto3
import os

def lambda_handler(event, context):
    load_balancer_arn = os.environ['LOAD_BALANCER_ARN']
    print(load_balancer_arn)
    ses = boto3.client('ses')
    email_from = os.environ['FROM']
    email_to = os.environ['TO']
    email_subject = 'CodePipeline Notification'
    email_body = 'Your CodePipeline deployment was successful!\n Here is the link to the website: https://mock-loadb-1n9o1q7uyuxvk-2290684a23aa684b.elb.ca-central-1.amazonaws.com'
    
    response = ses.send_email(
        Source=email_from,
        Destination={
            'ToAddresses': [email_to]
        },
        Message={
            'Subject': {
                'Data': email_subject
            },
            'Body': {
                'Text': {
                    'Data': email_body
                }
            }
        }
    )
    return response
